#
# This file is part of VIRL 2
# Copyright (c) 2019, Cisco Systems, Inc.
# All rights reserved.
#
import logging
import time
from functools import total_ordering
from itertools import chain

from simple_client import InterfaceNotFound

logger = logging.getLogger(__name__)

flatten = chain.from_iterable


@total_ordering
class Node:

    def __init__(self, lab, nid, label, node_definition, image_definition,
                 config, x, y, ram, cpus, data_volume, boot_disk_size, tags):
        """
        :param lab: the Lab this nodes belongs to
        :type lab: Lab
        :param nid: the Node ID
        :type nid: str
        :param node_definition: The node definition of this node
        :type node_definition: str
        :param image_definition: The image definition of this node
        :type image_definition: str
        :param config: The day0 configuration of this node
        :type config: str
        :param x: X coordinate on topology canvas
        :type x: int
        :param y: Y coordinate on topology canvas
        :type y: int
        :param ram: memory of node in MiB (if applicable)
        :type ram: int
        :param cpus: Amount of CPUs in this node (if applicable)
        :type cpus: int
        :param data_volume: Size in GiB of 2nd HDD (if > 0)
        :type data_volume: int
        :param boot_disk_size: Size in GiB of boot disk (will expand to this size)
        :type boot_disk_size: int
        :param tags: List of tags List[str, str]
        :type tags: list
        """
        self.lab = lab
        self.id = nid
        self._label = label
        self._node_definition = node_definition
        self._x = x
        self._y = y
        self.state = None
        self.session = lab.session
        self._image_definition = image_definition
        self._ram = ram
        self._config = config
        self._cpus = cpus
        self._data_volume = data_volume
        self._boot_disk_size = boot_disk_size
        self._tags = tags

        self.wait_for_convergence = lab.wait_for_convergence

        self.statistics = {
            "cpu_usage": 0,
            "disk_read": 0,
            "disk_write": 0
        }

    def __repr__(self):
        return "Node: {}".format(self.label)

    def __eq__(self, other):
        if not isinstance(other, Node):
            return False
        return self.id == other.id

    def __lt__(self, other):
        if not isinstance(other, Node):
            return False
        return int(self.id) < int(other.id)

    def __hash__(self):
        return hash(self.id)

    def interfaces(self):
        return [iface for iface in self.lab.interfaces()
                if iface.node is self]

    def physical_interfaces(self):
        return [iface for iface in self.interfaces()
                if iface.type == "physical"]

    def create_interface(self, slot=None, wait=False):
        """
        Create an interface in the specified slot or, if no slot is given, in the
        next available slot.

        :param slot: (optional)
        :type slot: int
        :param wait: Wait for the creation
        :type wait: bool
        :returns: The newly created interface
        :rtype: Interface
        """
        return self.lab.create_interface(self, slot, wait=wait)

    def peer_interfaces(self):
        peer_ifaces = (iface.peer_interfaces() for iface in self.interfaces())
        return list(set(flatten(peer_ifaces)))

    def peer_nodes(self):
        return list(set(iface.node for iface in self.peer_interfaces()))

    def links(self):
        return list(set(flatten(iface.links() for iface in self.interfaces())))

    def degree(self):
        return len(self.links())

    @property
    def label(self):
        return self._label

    @label.setter
    def label(self, value):
        self._set_node_property("label", value)
        self._label = value

    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, value):
        self._set_node_property("x", value)
        self._x = value

    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, value):
        self._set_node_property("y", value)
        self._y = value

    @property
    def ram(self):
        return self._ram

    @ram.setter
    def ram(self, value):
        self._set_node_property("ram", value)
        self._ram = value

    @property
    def cpus(self):
        return self._cpus

    @cpus.setter
    def cpus(self, value):
        self._set_node_property("cpus", value)
        self._cpus = value

    @property
    def data_volume(self):
        return self._data_volume

    @data_volume.setter
    def data_volume(self, value):
        self._set_node_property("data_volume", value)
        self._data_volume = value

    @property
    def boot_disk_size(self):
        return self._boot_disk_size

    @boot_disk_size.setter
    def boot_disk_size(self, value):
        self._set_node_property("boot_disk_size", value)
        self._boot_disk_size = value

    @property
    def config(self):
        return self._config

    @config.setter
    def config(self, value):
        url = self._base_url + "/config?origin_uuid={}".format(self.lab.client_uuid)
        response = self.session.put(url, data=value)
        response.raise_for_status()
        self._config = value

    @property
    def image_definition(self):
        return self._image_definition

    @image_definition.setter
    def image_definition(self, value):
        self._set_node_property("image_definition", value)
        self._image_definition = value

    @property
    def node_definition(self):
        return self._node_definition

    @node_definition.setter
    def node_definition(self, value):
        # TODO: enforce not allowed to change node definition for created nodes
        # can't change node definition
        raise NotImplementedError

    def _set_node_property(self, key, val):
        logger.info("Setting node property %s %s: %s", self, key, val)
        node_url = "{}?origin_uuid={}".format(self._base_url, self.lab.client_uuid)
        response = self.session.put(url=node_url, json={key: val})
        response.raise_for_status()

    @property
    def lab_base_url(self):
        return self.lab.lab_base_url

    @property
    def debug(self):
        return self.lab.debug

    @property
    def _base_url(self):
        return self.lab_base_url + "/nodes/{}".format(self.id)

    @property
    def cpu_usage(self):
        return min(self.statistics["cpu_usage"], 100)

    @property
    def disk_read(self):
        return round(self.statistics["disk_read"] / 1048576)

    @property
    def disk_write(self):
        return round(self.statistics["disk_write"] / 1048576)

    def get_interface_by_label(self, label):
        for iface in self.interfaces():
            if iface.label == label:
                return iface
        else:
            raise InterfaceNotFound("{}:{}".format(label, self))

    def wait_until_converged(self, max_iterations=500):
        logger.info("Waiting for node %s to converge", self.id)
        for index in range(max_iterations):
            converged = self.has_converged()
            if converged:
                logger.info("Node %s has booted", self.id)
                return

            if index % 10 == 0:
                logging.info("Node has not converged, attempt %s/%s, waiting...", index, max_iterations)
            time.sleep(5)
        logger.info("Node %s has not converged, maximum tries %s exceeded", self.id, max_iterations)

    def has_converged(self):
        url = self.lab_base_url + "/check_if_converged"
        response = self.session.get(url)
        response.raise_for_status()
        converged = response.json()
        return converged

    def start(self, wait=False):
        url = self._base_url + "/state/start"
        response = self.session.put(url)
        response.raise_for_status()
        if self.wait_for_convergence or wait:
            self.wait_until_converged()

    def stop(self, wait=False):
        url = self._base_url + "/state/stop"
        response = self.session.put(url)
        response.raise_for_status()
        if self.wait_for_convergence or wait:
            self.wait_until_converged()

    def wipe(self, wait=False):
        url = self._base_url + "/wipe_disks"
        response = self.session.put(url)
        response.raise_for_status()
        if self.wait_for_convergence or wait:
            self.wait_until_converged()

    def extract_configuration(self, wait=False):
        url = self._base_url + "/extract_configuration"
        response = self.session.put(url)
        response.raise_for_status()

    def remove_on_server(self):
        logger.info("Removing node %s", self)
        url = self._base_url
        response = self.session.delete(url)
        response.raise_for_status()

    def tags(self):
        return self._tags

    def add_tag(self, tag):
        current = self._tags
        current.append(tag)
        self._set_node_property("tags", current)

    def remove_tag(self, tag):
        current = self._tags
        current.remove(tag)
        self._set_node_property("tags", current)

    def run_pyats_command(self, command):
        label = self.label
        return self.lab.pyats.run_command(label, command)

    def sync_layer3_addresses(self):
        url = self._base_url + "/layer3_addresses"
        response = self.session.get(url)
        response.raise_for_status()
        result = response.json()
        interfaces = result.get("interfaces", {})
        self.map_l3_addresses_to_interfaces(interfaces)

    def map_l3_addresses_to_interfaces(self, mapping):
        for mac_address, entry in mapping.items():
            ipv4 = entry.get("ip4")
            ipv6 = entry.get("ip6")
            label = entry.get("label")
            iface = self.get_interface_by_label(label)
            if not iface:
                continue
            iface.ip_snooped_info = {
                "mac_address": mac_address,
                "ipv4": ipv4,
                "ipv6": ipv6
            }
