class NodeNotFound(Exception):
    pass


class LinkNotFound(Exception):
    pass


class InterfaceNotFound(Exception):
    pass


class LabNotFound(Exception):
    pass
