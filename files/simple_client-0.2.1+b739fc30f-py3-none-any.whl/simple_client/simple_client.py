#
# This file is part of VIRL 2
# Copyright (c) 2019, Cisco Systems, Inc.
# All rights reserved.
#

# TODO: make this Python <3.5 compatible
import json
import logging
import os
import urllib
import warnings
from functools import lru_cache
from pathlib import Path
from urllib.parse import urljoin

import pkg_resources
import requests
import urllib3
from requests import HTTPError

from simple_client import LabNotFound
from simple_client.models import Lab
from simple_client.models.authentication import Context, TokenAuth
from simple_client.models.node_image_definitions import NodeImageDefinitions


logger = logging.getLogger(__name__)
cached = lru_cache(maxsize=None)  # cache results forever


class InitializationError(Exception):
    pass


class ClientLibrary:
    """
    Example::

        from simple_client import ClientLibrary
        client = ClientLibrary("https://192.168.1.1", "username", "password")
        client.wait_for_lld_connected()

    A custom SSL certificate bundle can be passed in `ssl_verify`::

        client = ClientLibrary("https://192.168.1.1", "username", "password", ssl_verify="./cert.pem")

    You can pass a certificate using the ``CA_BUNDLE`` environment variable as well.

    If no username or password are given then the environment will be checked,
    looking for ``SIMPLE_USER`` and ``SIMPLE_PASS``, respectively. Environment
    variables take precedence over those provided in arguments.

    Disabling SSL certificate verification (not recommended)::

        client = ClientLibrary("https://192.168.1.1", "username", "password", ssl_verify=False)

    Creating a lab with nodes and links::

        lab = client.create_lab()

        r1 = lab.create_node("r1", "iosv", 50, 100)
        r1.config = "hostname router1"
        r2 = lab.create_node("r2", "iosv", 50, 200)
        r2.config = "hostname router2"

        # create a link between r1 and r2
        r1_i1 = r1.create_interface()
        r2_i1 = r2.create_interface()
        lab.create_link(r1_i1, r2_i1)

        lab.start()

        # print nodes and interfaces states:
        for node in lab.nodes():
            print(node, node.state, node.cpu_usage)
            for interface in node.interfaces():
                print(interface, interface.readpackets, interface.writepackets)

        lab.stop()

        lab.wipe()

        lab.remove_node(r2)

        lab.remove()





    Stopping all the labs::

        for lab in client_library.all_labs():
            lab.stop()

    Getting all lab names::

        all_labs_names = [lab.name for lab in client_library.all_labs()]

    A way to remove all the labs on the server is::

        lab_list = client_library.get_lab_list()
        for lab_id in lab_list:
            lab = client_library.join_existing_lab(lab_id)
            lab.stop()
            lab.wipe()
            client_library.remove_lab(lab_id)


    Uploading an image disk file:

        client_library.definitions.upload_image_file("/Users/username/Desktop/vios-adventerprisek9-m.spa.158-3.m2.qcow2", rename="iosv-test.qcow2")


    """

    def __init__(self, url, username=None, password=None, ssl_verify=True, raise_for_auth_failure=False):
        """
        Initializes a ClientLibrary instance. Note that ssl_verify can
        also be a string that points to a cert (see class documentation).

        :param url: URL of controller, including https://
        :type url: str
        :param username: Username of the user to authenticate
        :type username: str
        :param password: Password of the user to authenticate
        :type password: str
        :param ssl_verify: SSL controller certificate verification
        :type ssl_verify: bool
        :param raise_for_auth_failure: Raise an exception if unable to connect to server (use for scripting scenarios)
        :type raise_for_auth_failure: bool
        """

        # check environment for host URL
        env_url = os.environ.get("SIMPLE_URL")
        if env_url:
            logger.info("using URL from environment: %s", env_url)
            url = env_url
        base_url = urljoin(url, "api/v0/")


        # check environment for username
        env_user = os.environ.get("SIMPLE_USER")
        if username:
            self.username = username
        elif env_user:
            logger.info("Using username from environment: %s", env_user)
            self.username = env_user
        else:
            logger.warning("No username provided")
            raise Exception

        # check environment for password
        env_pass = os.environ.get("SIMPLE_PASS")
        if password:
            self.password = password
        elif env_pass:
            logger.info("using password from environment: %s", env_pass)
            self.password = env_pass
        else:
            logger.warning("no password provided")
            raise Exception

        self._context = Context(base_url)
        """
        Within the Client Library context:
        `requests.Session()` instance that can be used to send requests to the controller.
        `uuid.uuid4()` instance to uniquely identify this client library session.
        `base_url` stores the base URL
        """

        # http://docs.python-requests.org/en/master/user/advanced/#ssl-cert-verification

        ENV_CA_BUNDLE = os.environ.get("CA_BUNDLE")
        if ssl_verify is True and ENV_CA_BUNDLE:
            self.session.verify = ENV_CA_BUNDLE
        else:
            self.session.verify = ssl_verify

        if ssl_verify is False:
            # logger.warning("SSL Verification disabled")
            urllib3.disable_warnings()

        self.session.auth = TokenAuth(self)

        """
        `auto_sync` automatically syncs data with the backend after a specific
        time. The default expiry time is 1.0s. This time can be configured by
        setting the `auto_sync_interval`.
        """
        self.auto_sync = True
        self.auto_sync_interval = 1.0  # seconds

        self.definitions = NodeImageDefinitions(self._context)

        self._labs = {}

        try:
            self._make_test_call()
        except InitializationError as exc:
            if raise_for_auth_failure:
                raise
            else:
                logger.warning(exc)
                return

    def _make_test_call(self):
        # make a call to confirm auth working, this will be replaced by a Version check in SIMPLE-2188
        try:
            url = self._base_url + "labs"
            response = self.session.get(url)
            response.raise_for_status()
        except HTTPError as exc:
            response = exc.response
            status_code = response.status_code
            if status_code == requests.codes.forbidden:
                message = "Unable to authenticate, please check your username and password"
                raise InitializationError(message)
            else:
                raise
        except requests.exceptions.ConnectionError as exc:
            message = "Unable to connect to server"
            # TODO: subclass InitializationError
            raise InitializationError(message)

    @property
    def session(self):
        """
        Returns the used Requests session object
        :returns: The Requests session object
        :rtype: Requests.Session
        """
        return self._context.session

    @property
    def _base_url(self):
        """
        Returns the base URL to access the controller
        :returns: The base URL
        :rtype: str
        """
        return self._context.base_url

    def get_host(self):
        """
        Returns the hostname of the session to the controller.

        :returns: A hostname
        :rtype: str
        """
        split_url = urllib.parse.urlsplit(self._base_url)
        return split_url.hostname

    def wait_for_lld_connected(self):
        """
        Waits until the controller has a compute node connected.
        """
        response = self.session.get(urljoin(self._base_url, 'wait_for_lld_connected'))
        response.raise_for_status()

    def import_lab(self, topology, name, offline=False):
        """
        Imports an existing topology from a string.

        :param topology: Topology representation as a string
        :type topology: str
        :param name: Name of the lab
        :type name: str
        :param offline: whether the ClientLibrary should import the
            lab locally. The topology parameter has to be a JSON string
            in this case. This can not be XML or YAML representation of
            the lab.
        :type offline: bool
        :returns: A Lab instance
        :rtype: Lab
        :raises ValueError: if there's no lab ID in the API response
        :raises requests.exceptions.HTTPError: if there was a transport error
        """
        # TODO: refactor to return the local lab, and sync it, if already exists in self._labs
        if offline:
            lab_id = "offline_lab"
        else:
            if name.endswith(".virl"):
                url = "{}import/virl-1x?&name={}".format(self._base_url, name)
            elif name.endswith(".ng"):
                url = "{}import?is_json=true&name={}".format(self._base_url, name)
            else:
                url = "{}import?name={}".format(self._base_url, name)
            response = self.session.post(url, data=topology)
            response.raise_for_status()
            result = response.json()
            lab_id = result.get("id")
            if lab_id is None:
                raise ValueError("no lab ID returned!")

        # remove the extension (.ng, .yaml) to name the lab
        lab_name = name.replace(Path(name).suffix, "")
        lab = Lab(lab_name, lab_id, self._context,
                  auto_sync=self.auto_sync,
                  auto_sync_interval=self.auto_sync_interval)

        if offline:
            topology_json = json.loads(topology)
            lab.import_lab(topology_json)
        else:
            lab.sync()
        self._labs[lab_id] = lab
        return lab

    def import_lab_from_path(self, topology, name=None):
        """
        Imports an existing topology from a file / path.

        :param topology: Topology filename / path
        :type topology: str
        :param name: Name of the lab
        :type name: str
        :returns: A Lab instance
        :rtype: Lab
        """
        topology_path = Path(topology)
        if not topology_path.exists():
            raise Exception("{topology} can not be found".format(topology))

        topology = topology_path.read_text()
        name = name or topology_path.name
        return self.import_lab(topology, name)

    def import_sample_lab(self, topology_name):
        """
        Imports a built-in sample lab (this will be going away in the future).

        :param topology_name: Sample lab name with extension
        :type topology_name: str
        :returns: A Lab instance
        :rtype: Lab
        """
        warnings.warn("deprecated", DeprecationWarning)
        topology_file_path = Path("import_export") / "SampleData" / topology_name
        topology = pkg_resources.resource_string("simple_common", topology_file_path.as_posix())
        return self.import_lab(topology=topology.decode(), name=topology_name)

    def all_labs(self):
        """
        Retrieves a list of all defined labs.

        :returns: A list of lab instance
        :rtype: List[Lab]
        """
        # TODO: integrate this further with local labs - check if already exist
        response = self.session.get(urljoin(self._base_url, 'labs'))
        response.raise_for_status()
        lab_ids = response.json()
        result = []
        for lab_id in lab_ids:
            lab = self.join_existing_lab(lab_id)
            result.append(lab)

        return result

    def local_labs(self):
        # TODO: first sync with server to pull all possible labs
        return [lab for lab in self._labs.values()]

    def get_local_lab(self, lab_id):
        try:
            return self._labs[lab_id]
        except KeyError:
            raise LabNotFound(lab_id)

    def create_lab(self, name=None):
        """
        Creates an empty lab with the given name. If no name is given, then
        the created lab ID is set as the name.

        Note that the lab will be auto-syncing according to the Client Librarie's
        auto-sync setting when created. The lab has a property to override this
        on a per-lab basis.

        Example::

            lab = client_library.create_lab()
            print(lab.id)
            lab.create_node("r1", "iosv", 50, 100)

        :param name: The Lab name (or title)
        :type name: str
        :returns: A Lab instance
        :rtype: Lab
        """
        url = self._base_url + "labs"
        response = self.session.post(url)
        response.raise_for_status()
        result = response.json()
        lab_id = result["id"]
        lab = Lab(name or lab_id, lab_id, self._context,
                  auto_sync=self.auto_sync,
                  auto_sync_interval=self.auto_sync_interval)
        self._labs[lab_id] = lab
        return lab

    def remove_lab(self, lab_id):
        """
        Use carefully, it removes a given lab::

            client_library.remove_lab("lab_2")

        :param lab_id: The lab ID to be removed.
        :type lab_id: str
        """
        url = self._base_url + "labs/{}".format(lab_id)
        response = self.session.delete(url)
        response.raise_for_status()
        self._labs = {}

    def join_existing_lab(self, lab_id, sync_lab=True):
        """
        Creates a new ClientLibrary lab instance that is retrieved
        from the controller.

        If `sync_lab` is set to true, then synchronize current lab
        by applying the changes that were done in UI or in another
        ClientLibrary session.

        Join preexisting lab::

            lab = client_library.join_existing_lab("lab_1")

        :param lab_id: The lab ID to be removed.
        :type lab_id: str
        :param sync_lab: Syncronize changes.
        :type sync_lab: bool
        :returns: A Lab instance
        :rtype: Lab
        """
        # TODO: check if lab exists through REST call
        name = None
        # TODO: sync lab name
        lab = Lab(name, lab_id, self._context,
                  auto_sync=self.auto_sync,
                  auto_sync_interval=self.auto_sync_interval)
        if sync_lab:
            lab.sync()

        self._labs[lab_id] = lab
        return lab

    def get_diagnostics(self):
        url = self._base_url + "diagnostics"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()

    def find_labs_by_title(self, title):
        """

        :param title: The title to search for
        :return: A list of lab objects which match the title specified
        """
        url = self._base_url + "populate_lab_tiles"
        response = self.session.get(url)
        response.raise_for_status()

        labs = response.json()

        matched_lab_ids = []

        for lab_id, lab_data in labs.items():
            if lab_data["lab_title"] == title:
                matched_lab_ids.append(lab_id)

        matched_labs = []
        for lab_id in matched_lab_ids:
            lab = self.join_existing_lab(lab_id)
            matched_labs.append(lab)

        return matched_labs

    def get_lab_list(self):
        """Returns list of all lab IDs"""
        url = self._base_url + "labs"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
